﻿using Newtonsoft.Json;
using RegisterModule;
using SageFrame.Common;
using SageFrame.Dashboard;
using SageFrame.FontIconInjector;
using SageFrame.Framework;
using SageFrame.Utilities;
using SageFrame.Web;
using SageFrame.WebBuilder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Xml;

public partial class Modules_WebBuilder_WebbuilderEdit : BaseAdministrationUserControl
{
    public bool isDevelopmentMode = true;
    public int userModuleID = 0;
    public string enableHeader = "true";//enable header for webbbuilder and disable for module
    public string tempPageName = "webbuildertemppagename";
    public string pageExtension = string.Empty;
    public string settings = string.Empty;
    public string apiDataCollection = string.Empty;
    private string underConstruction = "Under Construction";
    public string OnlineStoreURL = string.Empty;
    public string DigiSphereApi = string.Empty;
    public string PortalDefaultPage = string.Empty;
    private bool isUnderConstruction = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        userModuleID = int.Parse(SageUserModuleID);
        pageExtension = SageFrameSettingKeys.PageExtension;
        SageFrameConfig sageConfig = new SageFrameConfig();
        OnlineStoreURL = sageConfig.GetSettingValueByIndividualKey(SageFrameSettingKeys.OnlineStore);
        DigiSphereApi = sageConfig.GetSettingValueByIndividualKey(SageFrameSettingKeys.DigiSphereApi);
        PortalDefaultPage = sageConfig.GetSettingValueByIndividualKey(SageFrameSettingKeys.PortalDefaultPage);
        if (enableHeader == "true")
            GetPagename();
        ControllerInoker objCntrlInvoker = new ControllerInoker();
        Dictionary<int, ControllerDetail> objAPIResult = objCntrlInvoker.FirstLoadAPI(tempPageName);
        string apiResultString = JsonConvert.SerializeObject(objAPIResult);
        this.Page.ClientScript.RegisterStartupScript(this.GetType(), "StartupViewScript", "var apiResultString=" + apiResultString.ToString(), true);
        GetOnlineTheme("1");
        GetComponent();
        RegisterSageGlobalVariable();
        IncludeJs("webBuilderJs",
            "/Modules/WebBuilder/js/components.js",
            "/Modules/WebBuilder/js/init.js",
            "/Modules/WebBuilder/js/Easylibrary.js",
            "/Modules/WebBuilder/js/colors.js",
            "/Modules/WebBuilder/js/tinyColorPicker.js",
           "/js/SageMediaManagement.js",
           "/js/jquery.validate.js",
            "/Modules/WebBuilder/js/WebBuilder.js"
            );
        if (isDevelopmentMode)
            IncludeJs("webbuilderdevelopmentjs", "/Modules/WebBuilder/js/extensions.js");
        IncludeJs("webBuilderExtrajs", "/Modules/WebBuilder/js/devExtraCommonJs.js");
        IncludeCss("webBuilderCss",
            "/Modules/WebBuilder/fonts/styles.css",
            "/Modules/WebBuilder/css/custom.css");
        ShowData();
        ReadFontFamily();
        //GetComponent();
        ltrEditorLogo.ImageUrl = LoadLogoImage("editor");
        string underConstruction = "Under Construction";
        SageFrameConfig sfConfig = new SageFrameConfig();
        string portalDefaultPage = sfConfig.GetSettingsByKey(SageFrameSettingKeys.PortalDefaultPage);
        if (portalDefaultPage.Replace("-", " ").ToLower() == underConstruction.ToLower())
        {
            isUnderConstruction = true;
        }
    }

    private void GetComponent()
    {
        string componentPath = Server.MapPath(@"~\Modules\WebBuilder\js\components.js");
        if (isDevelopmentMode && File.Exists(componentPath))
            File.Delete(componentPath);
        if (!File.Exists(componentPath))
        {
            //File.Create(componentPath);
            string componentList = string.Empty;
            WebBuilderController objWebbuilderController = new WebBuilderController();
            List<BuilderComponentJson> objComponentList = objWebbuilderController.GetComponentValue(userModuleID.ToString());
            componentList = JsonConvert.SerializeObject(objComponentList);
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "StartupViewScript", "var storedComponent=" + componentList.ToString(), true);
            SaveComponentToJS("var storedComponent=" + componentList.ToString() + ";", componentPath);
        }
    }

    private void SaveComponentToJS(string components, string componentPath)
    {
        try
        {
            using (StreamWriter writeToFile = new StreamWriter(componentPath))
            {
                writeToFile.Write(components);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    private void GetPagename()
    {
        string[] parameters = GetUrlParameters;
        if (parameters != null && parameters.Length > 0)
        {
            tempPageName = parameters[0].Replace("-", " ");
            userModuleID = 1317;
        }
        if (parameters == null || (parameters != null && parameters.Length == 0))
        {
            Response.Redirect(GetHostURL() + "/Webbuilder/" + PortalDefaultPage);
        }
    }
    private void ShowData()
    {
        WebBuilderController objWebController = new WebBuilderController();
        WebBuilderInfo objWebInfo = new WebBuilderInfo();
        objWebInfo.Culture = GetCurrentCultureName;
        objWebInfo.PortalID = GetPortalID;
        objWebInfo.UserModuleID = userModuleID;
        objWebInfo.PageName = tempPageName;
        objWebInfo = objWebController.GetEditDOMByID(objWebInfo);
        if (objWebInfo != null)
        {
            string data = string.Empty;
            //dynamic dyn = JsonConvert.DeserializeObject(objWebInfo.Settings);
            //if (dyn != null)
            //{

            //}
            settings = HttpUtility.HtmlEncode(objWebInfo.Settings);
            //if (tempPageName.ToLower() != underConstruction.ToLower())
            //{
            if (enableHeader == "true")
            {
                data = "<div class='editor-site-header clearfix'>";
                if (objWebInfo.HeaderEdit != null)
                    data += HttpUtility.HtmlDecode(objWebInfo.HeaderEdit.Replace("fakeHostURL", GetHostURL()));
                data += "</div>";
            }
            // }
            data += "<div class='editor-componentWrapper clearfix'>";
            if (objWebInfo.EditDOM != null)
                data += HttpUtility.HtmlDecode(objWebInfo.EditDOM.Replace("fakeHostURL", GetHostURL()));
            data += "</div>";
            if (tempPageName.ToLower() != underConstruction.ToLower())
            {
                data += "<div class='editor-site-footer'>";
                if (objWebInfo.FooterEdit != null)
                    data += HttpUtility.HtmlDecode(objWebInfo.FooterEdit.Replace("fakeHostURL", GetHostURL()));
                data += "</div>";
            }
            ltrWebBuilderData.Text = data;
        }

        //list all the pages here
        List<WebBuilderPages> objPageList = objWebController.GetPageList(GetPortalID);
        StringBuilder html = new StringBuilder();

        bool pageNotExists = true;
        foreach (WebBuilderPages objPages in objPageList)
        {
            string pageName = objPages.PageName.Replace(" ", "-").Replace("&", "-and-");
            if (tempPageName.Replace(" ", "-").ToLower() == pageName.ToLower())
                pageNotExists = false;
            if (AllowedPage(pageName))
            {
                html.Append("<li data-pageid='");
                html.Append(objPages.PageID);
                html.Append("' data-webbuilderid='");
                html.Append(objPages.WebbuilderID);
                html.Append("'>");
                html.Append("<a href=");
                html.Append(GetHostURL());
                html.Append("/");
                html.Append(pageName);
                //html.Append(SageFrameSettingKeys.PageExtension);
                html.Append(" class='pagelink'><span class='pageName editor-text-letterSpacing-0' style='font-size: 14px; color: rgb(217, 217, 217);'>");
                html.Append(objPages.PageName);
                html.Append("</span></a>");
                html.Append("</li>");
            }
        }
        if (pageNotExists)
            Response.Redirect(GetHostURL() + "/Webbuilder/" + PortalDefaultPage);
        ltrPageList.Text = html.ToString();
    }

    private bool AllowedPage(string checkPage)
    {
        bool pageAllowed = true;
        string[] notAllowedPages = { "Under Construction", "ourwebbuildernonvisiblepage", "login", "forgot password", "contact us manage" };
        foreach (string page in notAllowedPages)
        {
            if (page.Replace(" ", "-").Replace("&", "-and-").ToLower() == checkPage.ToLower())
                pageAllowed = false;
        }
        return pageAllowed;
    }
    private void ReadFontFamily()
    {
        FontInjectorController objFontIconController = new FontInjectorController();
        ltrFontFamily.Text = objFontIconController.GetFontDOM();
    }

    protected void lnkloginStatus_Click(object sender, EventArgs e)
    {
        SageFrameConfig SageConfig = new SageFrameConfig();
        SageFrameSettingKeys.PageExtension = SageConfig.GetSettingsByKey(SageFrameSettingKeys.SettingPageExtension);
        bool EnableSessionTracker = bool.Parse(SageConfig.GetSettingsByKey(SageFrameSettingKeys.EnableSessionTracker));
        if (EnableSessionTracker)
        {
            SageFrame.Web.SessionLog sLog = new SageFrame.Web.SessionLog();
            sLog.SessionLogEnd(GetPortalID);
        }
        SecurityPolicy objSecurity = new SecurityPolicy();
        HttpCookie authenticateCookie = new HttpCookie(objSecurity.FormsCookieName(GetPortalID));
        authenticateCookie.Expires = DateTime.Now.AddYears(-1);
        string randomCookieValue = GenerateRandomCookieValue();
        HttpContext.Current.Session[SessionKeys.RandomCookieValue] = randomCookieValue;
        Response.Cookies.Add(authenticateCookie);
        SetUserRoles(string.Empty);
        HttpContext.Current.Session[SessionKeys.ModuleCss] = new List<CssScriptInfo>();
        HttpContext.Current.Session[SessionKeys.ModuleJs] = new List<CssScriptInfo>();
        Response.Redirect(GetHostURL() + "/" + tempPageName.Replace(" ", "-"));
    }
    private string GenerateRandomCookieValue()
    {
        Random random = new Random();
        string s = "";
        string[] CapchaValue = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        for (int i = 0; i < 10; i++)
            s = String.Concat(s, CapchaValue[random.Next(36)]);
        return s;
    }

    public void RegisterSageGlobalVariable()
    {
        try
        {
            //StringBuilder clientScript = new StringBuilder();
            //clientScript.Append("var webBuilderUserModuleID='");
            //clientScript.Append(userModuleID);
            //clientScript.Append("';");

            CombineExtraJsFiles();
            CombineFiles();
            //clientScript.Append(" var webBuilderPageExtension='");
            //clientScript.Append("");
            //clientScript.Append("';");
            //clientScript.Append(" var portalDefaultPage='");
            //clientScript.Append(GetCurrentCulture());
            //clientScript.Append("';");
            //clientScript.Append(" var webbuildermodulepath='");
            //clientScript.Append("/modules/webbuilder");
            //clientScript.Append("';");

            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Webbuilder", clientScript.ToString(), true);
        }
        catch { }
    }
    /// <summary>
    /// Combines multiple js files and create a single extension.js file
    /// </summary>
    public void CombineExtraJsFiles()
    {
        if (isDevelopmentMode)
        {

            try
            {
                string extensionPath = Server.MapPath(@"~\Modules\WebBuilder\js\devExtraCommonJs.js");

                if (File.Exists(extensionPath)) File.Delete(extensionPath);

                string fullpath = Server.MapPath(@"~\Modules\WebBuilder\Packages\js");
                string[] files = Directory.GetFiles(fullpath, "*.js");

                // WAY 1
                if (files.Length > 0)
                {
                    using (StreamWriter writeToFile = new StreamWriter(extensionPath))
                    {
                        // writeToFile.WriteLine("var extraJs = {");
                        foreach (var file in files)
                        {
                            using (StreamReader readFrom = new StreamReader(file))
                            {
                                while (!readFrom.EndOfStream)
                                {
                                    string line = readFrom.ReadLine();
                                    //if (!line.StartsWith("var") && !line.StartsWith("}"))
                                    // {
                                    writeToFile.WriteLine(line);
                                    //}

                                }
                            }

                        }
                        writeToFile.WriteLine(" ");

                    }

                }
            }
            catch (Exception ex)
            {
                ProcessException(ex);
            }

            // WAY 2
            //FileParser fileParser = new FileParser();

            //string content = fileParser.CombineContentsInBetween(',', false, files);

            //StringBuilder clientScript = new StringBuilder();
            //clientScript.Append("var extendedComps = {");
            //clientScript.Append(content);
            //clientScript.Append(" }");

            //string extendedComp = clientScript.ToString();



            //try
            //{
            //    if (File.Exists(extensionPath))
            //        File.Delete(extensionPath);

            //    File.WriteAllText(extensionPath, extendedComp);
            //}
            //catch { }

        }


    }



    /// <summary>
    /// Combines multiple js files and create a single extension.js file
    /// </summary>
    public void CombineFiles()
    {
        if (isDevelopmentMode)
        {

            try
            {
                string extensionPath = Server.MapPath(@"~\Modules\WebBuilder\js\extensions.js");

                if (File.Exists(extensionPath)) File.Delete(extensionPath);

                string fullpath = Server.MapPath(@"~\Modules\WebBuilder\js\extensions");
                string[] files = Directory.GetFiles(fullpath, "*.js");

                // WAY 1
                if (files.Length > 0)
                {
                    using (StreamWriter writeToFile = new StreamWriter(extensionPath))
                    {
                        writeToFile.WriteLine("var extendedComps = {");
                        foreach (var file in files)
                        {
                            using (StreamReader readFrom = new StreamReader(file))
                            {
                                while (!readFrom.EndOfStream)
                                {
                                    string line = readFrom.ReadLine();
                                    if (!line.StartsWith("var") && !line.StartsWith("}"))
                                    {
                                        writeToFile.WriteLine(line);
                                    }

                                }
                                writeToFile.Write(',');
                            }

                        }
                        writeToFile.WriteLine("}");

                    }

                }
            }
            catch (Exception ex)
            {
                ProcessException(ex);
            }

            // WAY 2
            //FileParser fileParser = new FileParser();

            //string content = fileParser.CombineContentsInBetween(',', false, files);

            //StringBuilder clientScript = new StringBuilder();
            //clientScript.Append("var extendedComps = {");
            //clientScript.Append(content);
            //clientScript.Append(" }");

            //string extendedComp = clientScript.ToString();
            //try
            //{
            //    if (File.Exists(extensionPath))
            //        File.Delete(extensionPath);

            //    File.WriteAllText(extensionPath, extendedComp);
            //}
            //catch { }
        }
    }

    public void SetUserRoles(string strRoles)
    {
        Session[SessionKeys.SageUserRoles] = strRoles;
        HttpCookie cookie = HttpContext.Current.Request.Cookies[CookiesKeys.SageUserRolesCookie];
        if (cookie == null)
        {
            cookie = new HttpCookie(CookiesKeys.SageUserRolesCookie);
        }
        cookie[CookiesKeys.SageUserRolesProtected] = strRoles;
        HttpContext.Current.Response.Cookies.Add(cookie);
    }
    protected void btnExtractSite_Click(object sender, EventArgs e)
    {
        //check all the packages in this site
        //Read the extractor sp
        //execute the sp and save to the respective file
        //make zip of the packages 
        //extract site json file
        //create temporary folder and then make zip of all the file

        ///declaring paths
        string destZip = "temptemplatezip";
        string tempPackageFilePath = Server.MapPath(@"~\temptemplatefiles");
        string tempZipFolderPath = Server.MapPath(@"~\" + destZip);
        string fullpath = Server.MapPath(@"~\ContentderPackages");

        //create temporary folder for file collection
        if (Directory.Exists(tempPackageFilePath))
            Directory.Delete(tempPackageFilePath, true);
        Directory.CreateDirectory(tempPackageFilePath);

        WebBuilderController objController = new WebBuilderController();
        if (Directory.Exists(fullpath))
        {
            string[] directories = Directory.GetDirectories(fullpath);
            int directoryLength = directories.Length;
            List<EasyPackage> objPackage = new List<EasyPackage>();
            if (directoryLength > 0)
            {
                for (int i = 0; i < directoryLength; i++)
                {
                    EasyPackage objPack = new EasyPackage();
                    DirectoryInfo dir = new DirectoryInfo(directories[i]);
                    objPack.Name = dir.Name;
                    string xmlPath = directories[i] + "\\package.xml";
                    if (File.Exists(xmlPath))
                    {
                        XmlDocument doc = SageFrame.Templating.xmlparser.XmlHelper.LoadXMLDocument(xmlPath);
                        XmlNode node = doc.SelectSingleNode("package/datasql/sql");
                        if (node != null)
                        {
                            objPack.Sql = node.InnerText;
                        }
                        node = doc.SelectSingleNode("package/datasql/storeprocedure");
                        if (node != null)
                        {
                            objPack.Storeprocedure = node.InnerText;
                        }
                        node = doc.SelectSingleNode("package/datasql/paramkey");
                        if (node != null)
                        {
                            objPack.Paramkey = node.InnerText;
                        }
                        else
                        {
                            objPack.Paramkey = "@SiteID";
                        }
                        node = doc.SelectSingleNode("package/datasql/paramvalue");
                        if (node != null)
                        {
                            objPack.Paramvalue = node.InnerText;
                        }
                        else
                        {
                            objPack.Paramvalue = "0";
                        }
                        objPackage.Add(objPack);
                    }
                }

                objPackage = objController.ExtractPackageData(objPackage);

                //writing the data in respective sql file
                foreach (EasyPackage item in objPackage)
                {
                    string spSavePath = Server.MapPath(@"~\ContentderPackages\" + item.Name + "\\sql\\" + item.Sql + ".sql");
                    if (!File.Exists(spSavePath))
                        File.Create(spSavePath);
                    using (StreamWriter writetext = new StreamWriter(spSavePath))
                    {
                        writetext.WriteLine(item.Result);
                    }
                }

                //copy packages to temp folder
                DirectoryInfo tempDir = new DirectoryInfo(tempPackageFilePath + "\\Packages");
                DirectoryInfo packageDir = new DirectoryInfo(fullpath);
                IOHelper.CopyDirectory(packageDir, tempDir);
            }
        }
        //read json from database for site
        WebbuilderSite objWebsite = new WebbuilderSite();
        objWebsite = objController.ExtractSite(userModuleID, GetCurrentCulture(), GetHostURL());
        objWebsite.Culture = GetCurrentCulture();
        string jsonFile = JsonConvert.SerializeObject(objWebsite);

        //write extracted site json to file and save inside temporary folder
        string saveJson = tempPackageFilePath + "\\theme.json";
        //if (!File.Exists(saveJson))
        //    File.Create(saveJson);
        using (StreamWriter writetext = new StreamWriter(saveJson))
        {
            writetext.WriteLine(jsonFile);
        }
        //Create zip folder
        if (!Directory.Exists(tempZipFolderPath))
            Directory.CreateDirectory(tempZipFolderPath);

        //zip files inside the zip folder
        tempPackageFilePath += "\\";
        tempZipFolderPath += "\\Contentder.zip";
        destZip += "/Contentder.zip";
        ZipUtil.ZipFiles(tempPackageFilePath, tempZipFolderPath, string.Empty);
        if (destZip != string.Empty)
        {
            //download zip
            Response.Redirect(GetHostURL() + "/" + destZip);
            //delete the temporary package and zip folder
            IOHelper.DeleteDirectory(tempPackageFilePath);
            IOHelper.DeleteDirectory(tempZipFolderPath);
        }
    }

    public void GetOnlineTheme(string themeID)
    {
        decimal easyVersion = 0;
        decimal.TryParse(Config.GetSetting("SageFrameVersion"), out easyVersion);
        string apiUrl = OnlineStoreURL + "/GetOnlineThemePackage";
        ComponentPackage tempThemeDetail = new ComponentPackage();
        using (WebClient wc = new WebClient())
        {
            wc.Headers[HttpRequestHeader.ContentType] = "application/json";
            wc.QueryString.Add("themeID", themeID.ToString());
            wc.Encoding = Encoding.UTF8;
            var resultData = wc.DownloadString(apiUrl);
            dynamic dyn = JsonConvert.DeserializeObject(resultData);
            if (dyn != null)
            {
                tempThemeDetail = JsonConvert.DeserializeObject<ComponentPackage>(dyn.d.Value);
            }
            string themePackageFilePath = Server.MapPath(@"\downloadmyfiles");
            templateZipPath = themePackageFilePath;
            if (!Directory.Exists(themePackageFilePath))
                Directory.CreateDirectory(themePackageFilePath);
            successFileName = tempThemeDetail.FileName;
            string sendHostURl = OnlineStoreURL.Replace("Sage_Services/OnlineStore.asmx", "");
            tempThemeDetail.HostUrl = sendHostURl + tempThemeDetail.FolderName + "/" + tempThemeDetail.FileName;
            DownloadThemeZip(tempThemeDetail.HostUrl, themePackageFilePath + "\\theme.zip");
        }
    }
    string successFileName = string.Empty;
    string templateZipPath = string.Empty;
    string savetempZIPPath = string.Empty;

    public void DownloadThemeZip(string url, string savetempZIP)
    {
        using (System.Net.WebClient wc = new System.Net.WebClient())
        {
            wc.DownloadFileCompleted += DownloadThemeCompleted;
            wc.DownloadFileAsync(new Uri(url), savetempZIP);
            savetempZIPPath = savetempZIP;
        }
    }
    private void DownloadThemeCompleted(object sender, AsyncCompletedEventArgs e)
    {
        DownloadThemeSuccess();
    }

    private void DownloadThemeSuccess()
    {
        string[] args = new string[1];
        args[0] = successFileName;
        string service = "OnlineStore";
        string method = "ThemeDownloadSuccess";
        try
        {
            WebServiceInvoker invoker = new WebServiceInvoker(new Uri(OnlineStoreURL));
            invoker.InvokeMethod<string>(service, method, args);
            UnzipPackage();
        }
        catch
        {

        }
    }

    private void UnzipPackage()
    {
        string tempPackageExtractPath = Server.MapPath(@"~\tempPackageExtract");
        if (!Directory.Exists(tempPackageExtractPath))
            Directory.CreateDirectory(tempPackageExtractPath);
        string extractedPath = string.Empty;
        ZipUtil.UnZipFiles(savetempZIPPath, tempPackageExtractPath, ref extractedPath, SageFrame.Common.RegisterModule.Common.Password, true);

    }

}